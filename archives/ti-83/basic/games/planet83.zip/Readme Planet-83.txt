_______
|  |      |   |
|  |      |   |
|  |___|_| LANETARION - 83   
|  |
|_|


To Install - 
*simply send 'planet.83p' to your calculator

To Play -
*Choose a planet name (preferable 8 characters or less)
* Familiarise yourself with each menu 
* Play hard...

Tips - 
* You will get attacked randomly at certain scores... get to know what the scores are and avoid being in that score range, or you could lose everything you have.
* The game ends when your score hits 5 million.
* Get asteroids early so you can get lots of ships later on...

Remember -
* War Frigates are worth 500 to your score each...
* War Cruisers are worth 1500 to your score each...
* Ion Turrets are worth 2500 to your score each...


Good Luck and kick some Galactic Butt!