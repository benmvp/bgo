************************Final Fight*********************
****************search for the black orb****************
*********************511 programming********************
********************************************************

Contents
1.intro
2.game
3.end

--------------------------------------------------------
1. thanks for downloading the game final fight:serch for
   black orb.  this is an RPG and very entertaning 
   i hope that you enjoy the game. if you find any bugs
   or have any ideas please email me. my email address
   is below.
--------------------------------------------------------
2. the actual prog you exicute to play is "ffight" all 
   of the other progs are sub progs and wont let you 
   play the rest of the game. being an RPG this game 
   is rather large and can cause   your calculator to 
   run low on memory. there are 2 solutions to this. 
   
   1. delete all other progams. to save mem. 
   2. save the game often. speaks for itself

--------------------------------------------------------

thanks agian for playing final fight. 

questions/comments/bugs email me 

Lefinestpres@aol.com
